![alt text](https://github.com/Kai-TRD/DAM/blob/main/Lenguaje_de_marcas/mangak/images/banners/banner2.jpg?raw=true)
# Mangak
Proyecto de lenguaje de marcas
## Autor
* Kai
## Fuentes
* [LectorTMO](https://lectortmo.com/)
* [NineManga](https://my.ninemanga.com/)
* [Olympus Scans](https://olympusscans.com/)
* [Phoenix Fansub](https://phoenixfansub.com/)